import React from 'react';
import './App.css';
import NavbarContainer from './components/NavbarContainer';
import 'bootstrap/dist/css/bootstrap.min.css';
import './pexels-caio-46274.jpg';

const App = () => {
  return (
      <NavbarContainer>
      </NavbarContainer>
  );
}

export default App;
