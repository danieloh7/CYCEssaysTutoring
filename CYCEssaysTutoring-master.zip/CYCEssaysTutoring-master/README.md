# CYCEssaysTutoring


# !!!HOW TO SET UP BACKEND CONTACT FORM!!!!
https://medium.com/better-programming/a-simple-and-easy-contact-form-step-by-step-tutorial-react-js-1532bc025980
Follow Step 2, 3, 5, and 9: create an email for the real owner of the website.

# Then, Run this:
`$firebase functions:config:set gmail.email="<yourgmailusername(DO NOT ADD @gmail.com)>" gmail.password="<yourgmailpassword>"`

# Then this:
`$firebase deploy`
